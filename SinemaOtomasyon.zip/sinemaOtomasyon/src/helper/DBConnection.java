package helper;

import java.sql.*;

public class DBConnection {
	Connection c = null;

	public DBConnection() {

	}

	public Connection connDb() {
		try {
			this.c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/film?user=root&password=1q2w3e");

			return c;
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return c;

	}

}