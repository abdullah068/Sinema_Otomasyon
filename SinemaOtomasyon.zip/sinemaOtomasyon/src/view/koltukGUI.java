package view;

import java.awt.BorderLayout;
import model.koltuklar;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import helper.Helper;
import model.Film;
import model.Musteri;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import helper.DBConnection;
import javax.swing.JRadioButton;

public class koltukGUI extends JFrame {
	ArrayList<String> secilikoltuklar = new ArrayList<String>();
	int bilet_sayisi, bilet_fiyati, toplam_satis;
	String koltuk_adi, film_adi, tarih, kullanici_adi;
	static koltuklar k = new koltuklar();
	static Musteri musteri = new Musteri();
	static Film film = new Film();
	static Helper helper = new Helper();
	String koltuk, status;
	private JPanel contentPane;
	int key = 0;
	int count = 0;

	String bos_koltuk = "Y";
	private JTextField fld_koltukadi;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					koltukGUI frame = new koltukGUI(k);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public koltukGUI(koltuklar k) {
		film_adi = film.getFilm3_adi();
		tarih = film.getWdate2();
		kullanici_adi = musteri.getName();

		setTitle("Bilet Ekran\u0131");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 993, 636);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);

		JButton btnA2 = new JButton("A2");
		String k_durumA2 = k.koltukdurumu("A2", 1);
		if (k_durumA2.equals(bos_koltuk)) {
			btnA2.setBackground(Color.GREEN);

			btnA2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					key++;
					if (key % 2 == 1) {
						btnA2.setBackground(Color.WHITE);
						status = "N";
						k.koltuksecim(status, "A2");
						// key = 1;
						count++;
						bilet_sayisi = count;
						fld_koltukadi.setText("A2");
						secilikoltuklar.add(fld_koltukadi.getText());
						koltuk_adi = "A2";

					} else {
						btnA2.setBackground(Color.GREEN);
						status = "Y";
						k.koltuksecim(status, "A2");
						bilet_sayisi--;
					}
				}
			});
		} else {
			btnA2.setBackground(Color.RED);
			btnA2.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {

					helper.showMsg("DOLU KOLTUKLARI SE�EMEZS�N�Z.");

				}

			});
		}

		btnA2.setBounds(149, 79, 65, 57);
		panel.add(btnA2);

		JButton btnA3 = new JButton("A3");
		String k_durumA3 = k.koltukdurumu("A3", 1);
		if (k_durumA3.equals(bos_koltuk)) {
			btnA3.setBackground(Color.GREEN);

			btnA3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					key++;
					if (key % 2 == 1) {
						btnA3.setBackground(Color.WHITE);
						status = "N";
						k.koltuksecim(status, "A3");
						count++;
						bilet_sayisi = count;
						fld_koltukadi.setText("A3");
						secilikoltuklar.add(fld_koltukadi.getText());
						koltuk_adi = "A3";

					} else {
						btnA3.setBackground(Color.GREEN);
						status = "Y";
						k.koltuksecim(status, "A3");
						bilet_sayisi--;

					}
				}
			});
		} else {
			btnA3.setBackground(Color.RED);

			btnA3.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {

					helper.showMsg("DOLU KOLTUKLARI SE�EMEZS�N�Z.");

				}

			});

		}

		btnA3.setBounds(234, 79, 65, 57);
		panel.add(btnA3);

		JButton btnA1 = new JButton("A1");
		String k_durumA1 = k.koltukdurumu("A1", 1);
		if (k_durumA1.equals(bos_koltuk)) {
			btnA1.setBackground(Color.GREEN);

			btnA1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					key++;
					if (key % 2 == 1) {
						btnA1.setBackground(Color.WHITE);
						status = "N";
						k.koltuksecim(status, "A1");
						count++;
						bilet_sayisi = count;
						fld_koltukadi.setText("A1");
						secilikoltuklar.add(fld_koltukadi.getText());
						koltuk_adi = "A1";

					} else {
						btnA1.setBackground(Color.GREEN);
						status = "Y";
						k.koltuksecim(status, "A1");
						bilet_sayisi--;
					}
				}
			});
		} else {
			btnA1.setBackground(Color.RED);
			btnA1.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {

					helper.showMsg("DOLU KOLTUKLARI SE�EMEZS�N�Z.");

				}

			});
		}

		btnA1.setBounds(58, 79, 65, 57);

		panel.add(btnA1);

		JButton btnB3 = new JButton("B3");
		String k_durumB3 = k.koltukdurumu("B3", 1);
		if (k_durumB3.equals(bos_koltuk)) {
			btnB3.setBackground(Color.GREEN);

			btnB3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					key++;
					if (key % 2 == 1) {
						btnB3.setBackground(Color.WHITE);
						status = "N";
						k.koltuksecim(status, "B3");
						count++;
						bilet_sayisi = count;
						fld_koltukadi.setText("B3");
						secilikoltuklar.add(fld_koltukadi.getText());
						koltuk_adi = "B3";

					} else {
						btnB3.setBackground(Color.GREEN);
						status = "Y";
						k.koltuksecim(status, "B3");
						bilet_sayisi--;
					}
				}
			});
		} else {
			btnB3.setBackground(Color.RED);
			btnB3.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {

					helper.showMsg("DOLU KOLTUKLARI SE�EMEZS�N�Z.");

				}

			});
		}

		btnB3.setBounds(234, 161, 65, 57);
		panel.add(btnB3);

		JButton btnB2 = new JButton("B2");
		String k_durumB2 = k.koltukdurumu("B2", 1);
		if (k_durumB2.equals(bos_koltuk)) {
			btnB2.setBackground(Color.GREEN);

			btnB2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					key++;
					if (key % 2 == 1) {
						btnB2.setBackground(Color.WHITE);
						status = "N";
						k.koltuksecim(status, "B2");
						count++;
						bilet_sayisi = count;
						fld_koltukadi.setText("B2");
						secilikoltuklar.add(fld_koltukadi.getText());
						koltuk_adi = "B2";

					} else {
						btnB2.setBackground(Color.GREEN);
						status = "Y";
						k.koltuksecim(status, "B2");
						bilet_sayisi--;
					}
				}
			});
		} else {
			btnB2.setBackground(Color.RED);
			btnB2.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {

					helper.showMsg("DOLU KOLTUKLARI SE�EMEZS�N�Z.");

				}

			});
		}

		btnB2.setBounds(149, 161, 65, 57);
		panel.add(btnB2);

		JButton btnB1 = new JButton("B1");
		String k_durumB1 = k.koltukdurumu("B1", 1);
		if (k_durumB1.equals(bos_koltuk)) {
			btnB1.setBackground(Color.GREEN);

			btnB1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					key++;
					if (key % 2 == 1) {
						btnB1.setBackground(Color.WHITE);
						status = "N";
						k.koltuksecim(status, "B1");
						count++;
						bilet_sayisi = count;
						fld_koltukadi.setText("B1");
						secilikoltuklar.add(fld_koltukadi.getText());
						koltuk_adi = "B1";

					} else {
						btnB1.setBackground(Color.GREEN);
						status = "Y";
						k.koltuksecim(status, "B1");
						bilet_sayisi--;
					}
				}
			});
		} else {
			btnB1.setBackground(Color.RED);
			btnB1.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {

					helper.showMsg("DOLU KOLTUKLARI SE�EMEZS�N�Z.");

				}

			});
		}

		btnB1.setBounds(58, 161, 65, 57);
		panel.add(btnB1);

		JButton btnC3 = new JButton("C3");
		String k_durumC3 = k.koltukdurumu("C3", 1);
		if (k_durumC3.equals(bos_koltuk)) {
			btnC3.setBackground(Color.GREEN);

			btnC3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					key++;
					if (key % 2 == 1) {
						btnC3.setBackground(Color.WHITE);
						status = "N";
						k.koltuksecim(status, "C3");
						count++;
						bilet_sayisi = count;
						fld_koltukadi.setText("C3");
						secilikoltuklar.add(fld_koltukadi.getText());
						koltuk_adi = "C3";

					} else {
						btnC3.setBackground(Color.GREEN);
						status = "Y";
						k.koltuksecim(status, "C3");
						bilet_sayisi--;
					}
				}
			});
		} else {
			btnC3.setBackground(Color.RED);
			btnC3.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {

					helper.showMsg("DOLU KOLTUKLARI SE�EMEZS�N�Z.");

				}

			});
		}

		btnC3.setBounds(234, 245, 65, 57);
		panel.add(btnC3);

		JButton btnC2 = new JButton("C2");
		String k_durumC2 = k.koltukdurumu("C2", 1);
		if (k_durumC2.equals(bos_koltuk)) {
			btnC2.setBackground(Color.GREEN);

			btnC2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					key++;
					if (key % 2 == 1) {
						btnC2.setBackground(Color.WHITE);
						status = "N";
						k.koltuksecim(status, "C2");
						count++;
						bilet_sayisi = count;
						fld_koltukadi.setText("C2");
						secilikoltuklar.add(fld_koltukadi.getText());
						koltuk_adi = "C2";

					} else {
						btnC2.setBackground(Color.GREEN);
						status = "Y";
						k.koltuksecim(status, "C2");
						bilet_sayisi--;
					}
				}
			});
		} else {
			btnC2.setBackground(Color.RED);
			btnC2.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {

					helper.showMsg("DOLU KOLTUKLARI SE�EMEZS�N�Z.");

				}

			});
		}

		btnC2.setBounds(149, 245, 65, 57);
		panel.add(btnC2);

		JButton btnC1 = new JButton("C1");
		String k_durumC1 = k.koltukdurumu("C1", 1);
		if (k_durumC1.equals(bos_koltuk)) {
			btnC1.setBackground(Color.GREEN);

			btnC1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					key++;
					if (key % 2 == 1) {
						btnC1.setBackground(Color.WHITE);
						status = "N";
						k.koltuksecim(status, "C1");
						count++;
						bilet_sayisi = count;
						fld_koltukadi.setText("C1");
						koltuk_adi = "C1";

					} else {
						btnC1.setBackground(Color.GREEN);
						status = "Y";
						k.koltuksecim(status, "C1");
						bilet_sayisi--;
					}
				}
			});
		} else {
			btnC1.setBackground(Color.RED);
			btnC1.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {

					helper.showMsg("DOLU KOLTUKLARI SE�EMEZS�N�Z.");

				}

			});
		}

		btnC1.setBounds(58, 245, 65, 57);
		panel.add(btnC1);

		JLabel lblNewLabel = new JLabel(" PERDE");
		lblNewLabel.setBounds(85, 11, 186, 57);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 50));
		panel.add(lblNewLabel);

		JButton btnKoltukOnay = new JButton("ONAYLA");
		btnKoltukOnay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					k.biletlerim(koltuk_adi, koltuklar.dfilmadi, koltuklar.dwdate, koltuklar.dkullanici_adi);

				} catch (SQLException e1) {

					e1.printStackTrace();
				}
				helper.showMsg(bilet_fiyati + "TL �creti �demeyi onayl�yormusunuz?");
				helper.showMsg("Giri� ekran�na y�nlendiriliyorsunuz.");
				LoginGUI login = new LoginGUI();
				login.setVisible(true);
				dispose();
			}
		});
		btnKoltukOnay.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 26));
		btnKoltukOnay.setBounds(622, 486, 186, 50);
		panel.add(btnKoltukOnay);

		JLabel lblNewLabel_1 = new JLabel("DOLU KOLTUKLAR");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Light", Font.PLAIN, 22));
		lblNewLabel_1.setBounds(124, 328, 174, 32);
		panel.add(lblNewLabel_1);

		JTextPane textPane = new JTextPane();
		textPane.setBackground(Color.RED);
		textPane.setBounds(58, 328, 37, 32);
		panel.add(textPane);

		JButton btnrenci = new JButton("\u00D6\u011Frenci - 12\u20BA");
		btnrenci.addActionListener(new ActionListener() {
			int key2 = 0;

			public void actionPerformed(ActionEvent e) {
				key2++;
				if (key2 % 2 == 1) {
					btnrenci.setBackground(Color.GRAY);
					bilet_fiyati += bilet_sayisi * 12;
				} else {
					btnrenci.setBackground(Color.WHITE);
					bilet_fiyati -= bilet_sayisi * 12;
				}

			}
		});
		btnrenci.setFont(new Font("Yu Gothic UI Light", Font.PLAIN, 20));
		btnrenci.setBounds(85, 488, 186, 51);
		panel.add(btnrenci);

		JButton btnTam = new JButton("Tam - 15\u20BA");
		btnTam.addActionListener(new ActionListener() {
			int key2 = 0;

			public void actionPerformed(ActionEvent e) {
				key2++;
				if (key2 % 2 == 1) {
					btnTam.setBackground(Color.GRAY);
					bilet_fiyati += bilet_sayisi * 15;
				} else {
					btnTam.setBackground(Color.WHITE);
					bilet_fiyati -= bilet_sayisi * 15;
				}

			}
		});
		btnTam.setFont(new Font("Yu Gothic UI Light", Font.PLAIN, 20));
		btnTam.setBounds(334, 488, 186, 51);
		panel.add(btnTam);

		JLabel lblNewLabel_1_1 = new JLabel("BO\u015E KOLTUKLAR");
		lblNewLabel_1_1.setFont(new Font("Yu Gothic UI Light", Font.PLAIN, 22));
		lblNewLabel_1_1.setBounds(125, 371, 174, 32);
		panel.add(lblNewLabel_1_1);

		JTextPane textPane_1 = new JTextPane();
		textPane_1.setBackground(Color.GREEN);
		textPane_1.setBounds(59, 371, 37, 32);
		panel.add(textPane_1);

		JLabel lblSalonAd = new JLabel("SALON \u0130SM\u0130: " + koltuklar.salonid2 + ". Salon");
		lblSalonAd.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblSalonAd.setBounds(506, 96, 317, 35);
		panel.add(lblSalonAd);

		JLabel lblFilmIsmi = new JLabel("F\u0130LM \u0130SM\u0130: " + koltuklar.dfilmadi);
		lblFilmIsmi.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblFilmIsmi.setBounds(506, 178, 317, 35);
		panel.add(lblFilmIsmi);

		JLabel lblTarih = new JLabel("TAR\u0130H: " + koltuklar.dwdate);
		lblTarih.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblTarih.setBounds(506, 262, 317, 35);
		panel.add(lblTarih);

		JTextPane textPane_2 = new JTextPane();
		textPane_2.setBackground(Color.WHITE);
		textPane_2.setBounds(58, 415, 37, 32);
		panel.add(textPane_2);

		JLabel lblNewLabel_1_1_1 = new JLabel("SE\u00C7\u0130LEN KOLTUKLAR");
		lblNewLabel_1_1_1.setFont(new Font("Yu Gothic UI Light", Font.PLAIN, 22));
		lblNewLabel_1_1_1.setBounds(125, 415, 196, 32);
		panel.add(lblNewLabel_1_1_1);

		fld_koltukadi = new JTextField();
		fld_koltukadi.setFont(new Font("Yu Gothic UI Light", Font.PLAIN, 18));
		fld_koltukadi.setColumns(10);
		fld_koltukadi.setBounds(510, 339, 260, 38);
		panel.add(fld_koltukadi);

	}
}
