package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import helper.*;
import model.*;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JTable;

public class MusteriGUI extends JFrame {

	private JPanel w_pane;
	private static Musteri musteri = new Musteri();
	private static Helper helper = new Helper();
	private static koltuklar k = new koltuklar();
	private Hall hall = new Hall();
	private Film film = new Film();
	private DefaultTableModel biletlerimModel = new DefaultTableModel();
	private Object[] biletlerimData = new Object[3];
	private Object[] aramaliSeansData = new Object[3];
	private DefaultTableModel filmModel;
	private Object[] filmData = null;
	private Object[] seansData = null;
	private JTable table_filmSeans;
	private DefaultTableModel filmSeansModel;
	private DefaultTableModel filmAramaliSeansModel;
	private JTextField fld_filmID;
	private DBConnection conn = new DBConnection();
	private JTextField fld_filmadi;
	private JTextField fld_wdate;
	private JTable table_biletlerim;
	LoginGUI lGUI = new LoginGUI();
	private JTextField fld_filmSorgu;
	String filmSeans;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					MusteriGUI frame = new MusteriGUI(musteri);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @throws SQLException
	 */
	public MusteriGUI(Musteri musteri) throws SQLException {

		// Film Seans Model

		filmSeansModel = new DefaultTableModel();
		Object[] colseansFilmName = new Object[4]; // User db'de 4 kolon var ve biz 4 kolonu g�rmek istedi�imiz i�in 4
													// nesneli
		colseansFilmName[0] = "ID";
		colseansFilmName[1] = "Salon ID";
		colseansFilmName[2] = "Film ismi";
		colseansFilmName[3] = "Seans";
		filmSeansModel.setColumnIdentifiers(colseansFilmName);
		seansData = new Object[4];
		for (int i = 0; i < film.getSeansFilmList().size(); i++) {
			seansData[0] = film.getSeansFilmList().get(i).getId();
			seansData[1] = film.getSeansFilmList().get(i).getSalonID();
			seansData[2] = film.getSeansFilmList().get(i).getFilm_name();
			seansData[3] = film.getSeansFilmList().get(i).getWdate();

//			seansData[3] = film.getSeansFilmList().get(i).getStatus2();
			filmSeansModel.addRow(seansData);

		}

		filmAramaliSeansModel = new DefaultTableModel();
		Object[] colAramaliseansFilmName = new Object[4]; // User db'de 4 kolon var ve biz 4 kolonu g�rmek istedi�imiz
															// i�in 4 nesneli
		colAramaliseansFilmName[0] = "ID";
		colAramaliseansFilmName[1] = "Salon ID";
		colAramaliseansFilmName[2] = "Film ismi";
		colAramaliseansFilmName[3] = "Seans";
		filmAramaliSeansModel.setColumnIdentifiers(colAramaliseansFilmName);
		aramaliSeansData = new Object[4];
		for (int i = 0; i < film.getSeansFilmList(filmSeans).size(); i++) {
			aramaliSeansData[0] = film.getSeansFilmList(filmSeans).get(i).getId();
			aramaliSeansData[1] = film.getSeansFilmList(filmSeans).get(i).getSalonID();
			aramaliSeansData[2] = film.getSeansFilmList(filmSeans).get(i).getFilm_name();
			aramaliSeansData[3] = film.getSeansFilmList(filmSeans).get(i).getWdate();

//			seansData[3] = film.getSeansFilmList().get(i).getStatus2();
			filmAramaliSeansModel.addRow(aramaliSeansData);

		}

		// film Model

		filmModel = new DefaultTableModel();
		Object[] colfilm = new Object[3];
		colfilm[0] = "ID";
		colfilm[1] = "film_adi";
		colfilm[2] = "tur";
		filmModel.setColumnIdentifiers(colfilm);
		filmData = new Object[4];

		// Biletlerim Model

		biletlerimModel = new DefaultTableModel();
		Object[] colBiletlerim = new Object[3];
		colBiletlerim[0] = "Koltuk Ad�";
		colBiletlerim[1] = "Film Ad�";
		colBiletlerim[2] = "Tarih";

		biletlerimModel.setColumnIdentifiers(colBiletlerim);

		for (int i = 0; i < musteri.getBiletlerimList().size(); i++) {
			biletlerimData[0] = musteri.getBiletlerimList().get(i).getKoltuk_adi();
			biletlerimData[1] = musteri.getBiletlerimList().get(i).getFilm_adi();
			biletlerimData[2] = musteri.getBiletlerimList().get(i).getTarih();
			biletlerimModel.addRow(biletlerimData);

		}

		setResizable(false);
		setTitle("Sinema Y\u00F6netim Sistemi");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 994, 636);
		w_pane = new JPanel();
		w_pane.setBackground(Color.LIGHT_GRAY);
		w_pane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(w_pane);
		w_pane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Ho\u015Fgeldiniz, Say\u0131n " + musteri.getName());
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblNewLabel.setBounds(10, 11, 317, 35);
		w_pane.add(lblNewLabel);

		JButton btnNewButton = new JButton("\u00C7\u0131k\u0131\u015F Yap");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				helper.showMsg("��k�� yapmak istedi�inizden eminmisiniz.");
				LoginGUI login = new LoginGUI();
				login.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		btnNewButton.setBounds(822, 11, 144, 35);
		w_pane.add(btnNewButton);

		JTabbedPane w_tap = new JTabbedPane(JTabbedPane.TOP);
		w_tap.setBounds(10, 113, 968, 483);
		w_pane.add(w_tap);

		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		w_tap.addTab("Bilet Al", null, panel, null);
		panel.setLayout(null);

		JLabel lblSinemaSalonu_1 = new JLabel("Film Seanslar\u0131");
		lblSinemaSalonu_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblSinemaSalonu_1.setBounds(20, 23, 294, 35);
		panel.add(lblSinemaSalonu_1);

		JScrollPane w_scrollFilm_1 = new JScrollPane();
		w_scrollFilm_1.setBounds(20, 57, 652, 246);
		panel.add(w_scrollFilm_1);

		table_filmSeans = new JTable(filmSeansModel);
		w_scrollFilm_1.setViewportView(table_filmSeans);
		table_filmSeans.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent e) {
				fld_filmID.setText(table_filmSeans.getValueAt(table_filmSeans.getSelectedRow(), 1).toString());
				fld_filmadi.setText(table_filmSeans.getValueAt(table_filmSeans.getSelectedRow(), 2).toString());
				fld_wdate.setText(table_filmSeans.getValueAt(table_filmSeans.getSelectedRow(), 3).toString());
				koltuklar.salonid2 = Integer.parseInt(fld_filmID.getText());
				koltuklar.dfilmadi = fld_filmadi.getText();
				koltuklar.dwdate = fld_wdate.getText();
//				koltuklar.filmismi = 
			}
		});

		JButton btnNewButton_1_1_1 = new JButton("koltuk se\u00E7");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (fld_filmID.getText().length() == 0) {
					Helper.showMsg("L�tfen bir film se�iniz");

				} else {

					try {
						Connection con = conn.connDb();
						Statement st = con.createStatement();
						ResultSet rs = st.executeQuery("SELECT * FROM film.koltuklar");
						while (rs.next()) {
							koltuklar k = new koltuklar();
							k.setId(rs.getInt("id"));
							k.setSalonid(rs.getInt("salonid"));
							k.setKoltuk_adi(rs.getString("koltuk_adi"));
							k.setStatus(rs.getString("status"));
							koltukGUI kGUI = new koltukGUI(k);
							kGUI.setVisible(true);
							dispose();

						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				}
			}
		});
		btnNewButton_1_1_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 26));
		btnNewButton_1_1_1.setBounds(330, 382, 260, 50);
		panel.add(btnNewButton_1_1_1);

		fld_filmID = new JTextField();
		fld_filmID.setFont(new Font("Yu Gothic UI Light", Font.PLAIN, 18));
		fld_filmID.setColumns(10);
		fld_filmID.setBounds(20, 333, 260, 38);
		panel.add(fld_filmID);

		fld_filmadi = new JTextField();
		fld_filmadi.setFont(new Font("Yu Gothic UI Light", Font.PLAIN, 18));
		fld_filmadi.setColumns(10);
		fld_filmadi.setBounds(330, 333, 260, 38);
		panel.add(fld_filmadi);

		fld_wdate = new JTextField();
		fld_wdate.setFont(new Font("Yu Gothic UI Light", Font.PLAIN, 18));
		fld_wdate.setColumns(10);
		fld_wdate.setBounds(640, 333, 260, 38);
		panel.add(fld_wdate);

		fld_filmSorgu = new JTextField();
		fld_filmSorgu.setText("Film ad\u0131 giriniz");
		fld_filmSorgu.setFont(new Font("Yu Gothic UI Light", Font.PLAIN, 18));
		fld_filmSorgu.setColumns(10);
		fld_filmSorgu.setBounds(682, 99, 260, 38);
		panel.add(fld_filmSorgu);

		JLabel lblSinemaSalonu_1_1 = new JLabel("Film Sorgulama");
		lblSinemaSalonu_1_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblSinemaSalonu_1_1.setBounds(682, 58, 260, 35);
		panel.add(lblSinemaSalonu_1_1);

		JButton btnNewButton_1_1_1_1 = new JButton("ARA");
		btnNewButton_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				filmSeans = fld_filmSorgu.getText();
				if (filmSeans != "Film ad� giriniz") {

					DefaultTableModel clearModel = (DefaultTableModel) table_filmSeans.getModel();
					clearModel.setRowCount(0);
					try {
						for (int i = 0; i < film.getSeansFilmList(filmSeans).size(); i++) {
							aramaliSeansData[0] = film.getSeansFilmList(filmSeans).get(i).getId();
							aramaliSeansData[1] = film.getSeansFilmList(filmSeans).get(i).getSalonID();
							aramaliSeansData[2] = film.getSeansFilmList(filmSeans).get(i).getFilm_name();
							aramaliSeansData[3] = film.getSeansFilmList(filmSeans).get(i).getWdate();

//							seansData[3] = film.getSeansFilmList().get(i).getStatus2();
							filmAramaliSeansModel.addRow(aramaliSeansData);

						}
					} catch (Exception e2) {
						// TODO: handle exception
					}
					table_filmSeans.setModel(filmAramaliSeansModel);
				} else {
					Helper.showMsg("L�tfen bir salon se�iniz!");
				}
			}
		});
		btnNewButton_1_1_1_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 26));
		btnNewButton_1_1_1_1.setBounds(682, 154, 260, 50);
		panel.add(btnNewButton_1_1_1_1);

		JLabel lblSinemaSalonu_1_2 = new JLabel("Salon ID");
		lblSinemaSalonu_1_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblSinemaSalonu_1_2.setBounds(20, 301, 294, 35);
		panel.add(lblSinemaSalonu_1_2);

		JLabel lblSinemaSalonu_1_3 = new JLabel("Film Ad\u0131");
		lblSinemaSalonu_1_3.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblSinemaSalonu_1_3.setBounds(330, 301, 294, 35);
		panel.add(lblSinemaSalonu_1_3);

		JLabel lblSinemaSalonu_1_4 = new JLabel("Film Seans\u0131");
		lblSinemaSalonu_1_4.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblSinemaSalonu_1_4.setBounds(640, 301, 294, 35);
		panel.add(lblSinemaSalonu_1_4);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		w_tap.addTab("Biletlerim", null, panel_1, null);
		panel_1.setLayout(null);

		JScrollPane scrollBiletlerim = new JScrollPane();
		scrollBiletlerim.setBounds(10, 11, 943, 433);
		panel_1.add(scrollBiletlerim);

		table_biletlerim = new JTable(biletlerimModel);
		scrollBiletlerim.setViewportView(table_biletlerim);
	}
}
