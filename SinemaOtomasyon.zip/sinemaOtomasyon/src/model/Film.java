package model;

import java.sql.*;
import java.util.ArrayList;

import javax.swing.table.DefaultTableModel;

import helper.DBConnection;

public class Film {
	public ArrayList<Film> filmler;
	int ID, id, hall_id, film_id, salonID;
	String Film_adi, Tur, Status, film2_adi, film3_adi;
	String film_name, wdate, status2, h_name, wdate2;
	private DefaultTableModel filmModel = null;
	private Object[] filmData = null;
	DBConnection conn2 = new DBConnection();

	Statement st = null;
	ResultSet rs = null;
	PreparedStatement preparedStatement = null;

	public Film(int iD, String film_adi, String tur) {
		super();
		ID = iD;
		this.Film_adi = film_adi;
		this.Tur = tur;
	}

	public Film() {

	}

	public boolean addWhour(int salonID, int ID, String Film_adi, String wdate) throws SQLException {
		int key = 0;
		int count = 0;
		Connection con = conn2.connDb();
		String query = "INSERT INTO filmhour" + "(salonid,film_id,film_name,wdate) VALUES" + "(?,?,?,?)";

		try {
			st = con.createStatement();
			String a = "SELECT * FROM filmhour WHERE status='A' AND film_id =" + ID + " AND wdate='" + wdate + "'";
			rs = st.executeQuery(a);
			while (rs.next()) {
				count++;
				break;
			}

			if (count == 0) {
				preparedStatement = con.prepareStatement(query);
				preparedStatement.setInt(1, salonID);
				preparedStatement.setInt(2, ID);
				preparedStatement.setString(3, Film_adi);
				preparedStatement.setString(4, wdate);
				preparedStatement.executeUpdate();

			}

			key = 1;

		} catch (SQLException e) {

			e.printStackTrace();
		}

		if (key == 1)
			return true;
		else
			return false;

	}

	public ArrayList<Film> getFilmList() throws SQLException {
		ArrayList<Film> list = new ArrayList<>();
		Film obj;
		Connection con = conn2.connDb();
		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM filmler");
			while (rs.next()) {
				obj = new Film();
				obj.setID(rs.getInt("ID"));
				obj.setFilm_adi(rs.getString("Film_adi"));
				obj.setTur(rs.getString("Tur"));
				obj.setStatus(rs.getString("Status"));
				list.add(obj);

			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			st.close();
			rs.close();
			con.close();
		}

		return list;

	}

	public ArrayList<Film> getSFilmList() throws SQLException {
		ArrayList<Film> list = new ArrayList<>();
		Film obj;
		Connection con = conn2.connDb();
		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM filmhour");
			while (rs.next()) {
				obj = new Film();
				obj.setSalonID(rs.getInt("salonid"));
				obj.setFilm3_adi(rs.getString("Film_name"));
				obj.setWdate2(rs.getString("wdate"));
				list.add(obj);

			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			st.close();
			rs.close();
			con.close();
		}

		return list;

	}

	public ArrayList<Film> getSeansl�FilmList() throws SQLException {
		ArrayList<Film> list = new ArrayList<>();
		Film obj;
		Connection con = conn2.connDb();
		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM worker");
			while (rs.next()) {
				obj = new Film();
				obj.setFilm_id(rs.getInt("film_id"));
				obj.setHall_id(rs.getInt("hall_id"));
				obj.setFilm2_adi(rs.getString("film_adi"));

				list.add(obj);

			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			st.close();
			rs.close();
			con.close();
		}

		return list;

	}

	public ArrayList<Film> getSeansFilmList() throws SQLException {
		ArrayList<Film> list = new ArrayList<>();
		Film obj;
		Connection con = conn2.connDb();
		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM filmhour");
			while (rs.next()) {
				obj = new Film();
				obj.setId(rs.getInt("id"));
				obj.setSalonID(rs.getInt("salonid"));
				obj.setFilm_name(rs.getString("Film_name"));
				obj.setWdate(rs.getString("wdate"));
				list.add(obj);

			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			st.close();
			rs.close();
			con.close();
		}

		return list;

	}

	public ArrayList<Film> getSeansFilmList(String filmadi) throws SQLException {
		ArrayList<Film> list = new ArrayList<>();
		Film obj;
		Connection con = conn2.connDb();
		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM filmhour WHERE film_name LIKE '" + filmadi + "%'");
			while (rs.next()) {
				obj = new Film();
				obj.setId(rs.getInt("id"));
				obj.setSalonID(rs.getInt("salonid"));
				obj.setFilm_name(rs.getString("film_name"));
				obj.setWdate(rs.getString("wdate"));
				list.add(obj);

			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			st.close();
			rs.close();
			con.close();
		}

		return list;

	}

	public String getWdate() {
		return wdate;
	}

	public void setWdate(String wdate) {
		this.wdate = wdate;
	}

	public boolean deleteFilm(int ID) throws SQLException {
		String query = "DELETE FROM filmler WHERE ID = ?";
		boolean key = false;
		Connection con = conn2.connDb();
		try {
			st = con.createStatement();
			preparedStatement = con.prepareStatement(query); // g�nderilen parametreler veri taban� ile kar��la�t�r�l�r
																// hata olup olmad���n� da key yard�m� ile kontrol
																// ederiz
			preparedStatement.setInt(1, ID);
			preparedStatement.executeUpdate();
			key = true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (key)
			return true;
		else
			return false;
	}

	public boolean addFilmm(int film_id, int hall_id) throws SQLException { // salona filmi eklemek i�in
		String query = "INSERT INTO worker" + "(film_id,hall_id) VALUES" + "(?,?)";
		boolean key = false;
		int count = 0; // bir sinema salonunda ayn� ki�iyi iki defa g�revli g�stermemiz i�in sorgulama
						// yapd�k
		Connection con = conn2.connDb();
		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM worker WHERE hall_id=" + hall_id + " AND film_id=" + film_id);
			while (rs.next()) {
				count++;
			}

			if (count == 0) {
				preparedStatement = con.prepareStatement(query); // g�nderilen parametreler veri taban� ile
																	// kar��la�t�r�l�r hata olup olmad���n� da key
																	// yard�m� ile kontrol ederiz
				preparedStatement.setInt(1, film_id);
				preparedStatement.setInt(2, hall_id);
				preparedStatement.executeUpdate();

			}
			key = true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (key)
			return true;
		else
			return false;
	}

	public boolean addFilm(String Film_adi, String Tur) throws SQLException { // film ekleme i�lemleri i�in
		boolean key = false;

		String query = "INSERT INTO filmler" + "(Film_adi,Tur) VALUES" + "(?,?)";
		Connection con = conn2.connDb();

		try {
			st = con.createStatement();
			preparedStatement = con.prepareStatement(query); // g�nderilen parametreler veri taban� ile kar��la�t�r�l�r
																// hata olup olmad���n� da key yard�m� ile kontrol
																// ederiz

			preparedStatement.setString(1, Film_adi);
			preparedStatement.setString(2, Tur);
			preparedStatement.executeUpdate();
			key = true;

		} catch (SQLException e) {

			e.printStackTrace();
		}

		if (key)
			return true;
		else
			return false;

	}

	public boolean updateFilm(int ID, String film_adi) throws SQLException {
		String query = "UPDATE filmler SET film_adi = ? WHERE ID = ?";
		boolean key = false;
		Connection con = conn2.connDb();
		try {
			st = con.createStatement();
			preparedStatement = con.prepareStatement(query); // g�nderilen parametreler veri taban� ile kar��la�t�r�l�r
																// hata olup olmad���n� da key yard�m� ile kontrol
																// ederiz
			preparedStatement.setString(1, film_adi);
			preparedStatement.setInt(2, ID);
			preparedStatement.executeUpdate();
			key = true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (key)
			return true;
		else
			return false;
	}

	public int getSalonID() {
		return salonID;
	}

	public void setSalonID(int salonID) {
		this.salonID = salonID;
	}

	public String getFilm3_adi() {
		return film3_adi;
	}

	public void setFilm3_adi(String film3_adi) {
		this.film3_adi = film3_adi;
	}

	public String getWdate2() {
		return wdate2;
	}

	public void setWdate2(String wdate2) {
		this.wdate2 = wdate2;
	}

	public int getFilm_id() {
		return film_id;
	}

	public void setFilm_id(int film_id) {
		this.film_id = film_id;
	}

	public int getHall_id() {
		return hall_id;
	}

	public void setHall_id(int hall_id) {
		this.hall_id = hall_id;
	}

	public String getFilm2_adi() {
		return film2_adi;
	}

	public void setFilm2_adi(String film2_adi) {
		this.film2_adi = film2_adi;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFilm_name() {
		return film_name;
	}

	public void setFilm_name(String film_name) {
		this.film_name = film_name;
	}

	public String getStatus2() {
		return status2;
	}

	public void setStatus2(String status2) {
		this.status2 = status2;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		this.Status = status;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		this.ID = iD;
	}

	public String getFilm_adi() {
		return Film_adi;
	}

	public void setFilm_adi(String film_adi) {
		this.Film_adi = film_adi;
	}

	public String getTur() {
		return Tur;
	}

	public void setTur(String tur) {
		this.Tur = tur;
	}

}
