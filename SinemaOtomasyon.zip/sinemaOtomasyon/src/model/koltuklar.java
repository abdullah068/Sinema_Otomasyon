package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import helper.DBConnection;

public class koltuklar {

	DBConnection conn = new DBConnection();
	Connection con = conn.connDb();
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement preparedStatement = null;

	String status, koltuk_adi;
	int salonid, id;
	public static int salonid2;
	public static String dfilmadi, dwdate, dkullanici_adi;

	public static void main(String[] args) {

	}

	public boolean biletlerim(String koltuk_adi, String film_adi, String tarih, String kullanici_adi)
			throws SQLException {
		boolean key = false;

		String query = "INSERT INTO biletsatis" + "(koltuk_adi,film_adi,tarih,kullanici_adi) VALUES" + "(?,?,?,?)";
		Connection con = conn.connDb();

		try {
			st = con.createStatement();
			preparedStatement = con.prepareStatement(query); // g�nderilen parametreler veri taban� ile kar��la�t�r�l�r
																// hata olup olmad���n� da key yard�m� ile kontrol
																// ederiz

			preparedStatement.setString(1, koltuk_adi);
			preparedStatement.setString(2, film_adi);
			preparedStatement.setString(3, tarih);
			preparedStatement.setString(4, kullanici_adi);
			preparedStatement.executeUpdate();
			key = true;

		} catch (SQLException e) {

			e.printStackTrace();
		}

		if (key)
			return true;
		else
			return false;

	}

	public void koltuksecim(String status, String koltuk_adi) {
		String query = "UPDATE koltuklar SET status = ? WHERE koltuk_adi = ? AND salonid = ?";

		try {
			st = con.createStatement();

			preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1, status);
			preparedStatement.setString(2, koltuk_adi);
			preparedStatement.setInt(3, salonid2);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public String koltukdurumu(String koltuk_adi, int salonid) {
		String durum = "";

		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT status FROM film.koltuklar WHERE koltuk_adi ='" + koltuk_adi
					+ "' AND salonid =" + salonid2);
			while (rs.next()) {
				durum = rs.getString("status");
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return durum;

	}

	public koltuklar(String status, String koltuk_adi, int salonid) {
		super();
		this.status = status;
		this.koltuk_adi = koltuk_adi;
		this.salonid = salonid;
	}

	public koltuklar() {
		// TODO Auto-generated constructor stub
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getKoltuk_adi() {
		return koltuk_adi;
	}

	public void setKoltuk_adi(String koltuk_adi) {
		this.koltuk_adi = koltuk_adi;
	}

	public int getSalonid() {
		return salonid;
	}

	public void setSalonid(int salonid) {
		this.salonid = salonid;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void salonidCek(Object k) {
		// TODO Auto-generated method stub
		setSalonid((int) k);
	}

}
