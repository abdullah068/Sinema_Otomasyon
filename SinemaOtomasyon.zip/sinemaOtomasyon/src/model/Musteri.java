package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import helper.Helper;

public class Musteri extends user {
	public ArrayList<Musteri> getBiletList;
	Connection con = conn.connDb();
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement preparedStatement = null;
	String koltuk_adi, film_adi, tarih, kullanici_adi;
	public Object getBiletlerimList;

	public Musteri() {

	}

	public Musteri(int id, String name, String password, String userID, String type) {
		super(id, name, password, userID, type);

	}

	public boolean register(String UserID, String password, String name) throws SQLException {
		int key = 0;
		boolean duplicate = false;

		String query = "INSERT INTO user" + "(UserID,password,name,type) VALUES" + "(?,?,?,?)";

		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM user WHERE password='" + password + "'");
			while (rs.next()) {
				duplicate = true;
				Helper.showMsg("Bu kullan�c� ad� kullan�lmaktad�r.");
				break;

			}

			if (!duplicate) {
				preparedStatement = con.prepareStatement(query);
				preparedStatement.setString(1, UserID);
				preparedStatement.setString(2, password);
				preparedStatement.setString(3, name);
				preparedStatement.setString(4, "Musteri");
				preparedStatement.executeUpdate();
				key = 1;
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		if (key == 1)
			return true;
		else
			return false;

	}

	public ArrayList<Musteri> getBiletlerimList() throws SQLException {
		ArrayList<Musteri> list = new ArrayList<>();
		Musteri obj;
		Connection con = conn.connDb();
		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM biletsatis WHERE kullanici_adi= '" + UserID + "'");
			while (rs.next()) {
				obj = new Musteri();
				obj.setKoltuk_adi(rs.getString("koltuk_adi"));
				obj.setFilm_adi(rs.getString("film_adi"));
				obj.setTarih(rs.getString("tarih"));
				obj.setKullanici_adi(rs.getString("kullanici_adi"));
				list.add(obj);

			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			st.close();
			rs.close();
			con.close();
		}

		return list;

	}

	public String getKoltuk_adi() {
		return koltuk_adi;
	}

	public void setKoltuk_adi(String koltuk_adi) {
		this.koltuk_adi = koltuk_adi;
	}

	public String getFilm_adi() {
		return film_adi;
	}

	public void setFilm_adi(String film_adi) {
		this.film_adi = film_adi;
	}

	public String getTarih() {
		return tarih;
	}

	public void setTarih(String tarih) {
		this.tarih = tarih;
	}

	public String getKullanici_adi() {
		return kullanici_adi;
	}

	public void setKullanici_adi(String kullanici_adi) {
		this.kullanici_adi = kullanici_adi;
	}

}
